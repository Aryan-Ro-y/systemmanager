# :warning: This example has moved :warning:

You can find the updated and maintained example in the [aws-systems-manager repository](https://github.com/CrowdStrike/aws-ssm-distributor). The new version includes numerous fixes and enhancements.

Please note that the example in this folder will no longer receive maintenance and may be removed in the future.

:no_entry_sign: everything below is the old example :no_entry_sign:
---

# Setup Instructions
Please see the setup guide [here](https://github.com/CrowdStrike/Cloud-AWS/blob/master/systems-manager/documentation/AWS-Systems-Manager-Intro.md#option-b---creating-a-package-without-the-installer)