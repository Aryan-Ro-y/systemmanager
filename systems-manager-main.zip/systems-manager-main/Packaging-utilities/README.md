# :warning: This example has moved :warning:

You can find the updated and maintained example in the [aws-systems-manager repository](https://github.com/CrowdStrike/aws-ssm-distributor). The new version includes numerous fixes and enhancements.

Please note that the example in this folder will no longer receive maintenance and may be removed in the future.

:no_entry_sign: everything below is the old example :no_entry_sign:
---

# Packaging Utilities

## Create your AWS SSM package

Scripts and example files for creating your
ssm [Distributor](https://docs.aws.amazon.com/systems-manager/latest/userguide/distributor.html) package.